/*
 * VSIPC (Very Simple IPC) Copyright (C) 2003 Michel Blomgren.
 * This is an alpha 'proof-of-concept' version.
 * http://vsipc.sourceforge.net - michel AT zebra DOT ath DOT cx.
 *
 * These macros are not to be considered as an alternative to MPI, as you
 * pretty soon will notice. They only do one simple thing; make communication
 * between two processes more simple, meaning that forking a computation
 * (function) into a new process and having it communicate back the result is
 * easily implemented without setting up fork(), pipe() and various
 * data-structures for one or all of the functions by hand.
 *
 * VSIPC is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 * 
 * VSIPC is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
 * more details ("COPYING"-file).
 *
 * vsipc.h should be included together with the following headers...
 *

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

#include "vsipc.h"

 *
 * For usage, please read the comments for each macro below, or the manpage...
 *
 */


/*
 * NOTE: All macros set the "ff_errno" int to non-zero if an error occured.
 */


/*
 * Put "ff_data" (without "();", on a line by itself) before or just after
 * your data-definitions, e.g. right after "int main() {".
 */
#define ff_data \
	int ff_errno = 0; \
	int *pfd_table = NULL; \
	pid_t *pid_table = NULL; \
	unsigned int pfd_table_curpos = 0; \
	unsigned int pfd_mallocated = 0; \
	unsigned int pid_mallocated = 0; \
	unsigned int pfd_count = 0;


/*
 * Simple fork and wait macro for functions. A very trivial example:
 * 
 *	unsigned int i;
 *	char name[] = "Yoda";
 *
 *	ff(i, printf, "hello %s!\n", name);
 */
#define ff(ret, function, args...) \
{ \
	int pfd[2]; \
	pid_t pid; \
\
	if (pipe(pfd) != -1) \
	{ \
		pid = fork(); \
		if (!pid) \
		{ \
			close(pfd[0]); \
			ret = function(args); \
			write(pfd[1], &ret, sizeof(ret)); \
			close(pfd[1]); \
			exit(0); \
		} \
		else if (pid > 0) \
		{ \
			close(pfd[1]); \
			read(pfd[0], &ret, sizeof(ret)); \
			wait(NULL); \
			close(pfd[0]); \
		} \
		else \
		{	ff_errno = -1;	} \
	} \
	else \
	{	ff_errno = -1;	} \
}



/*
 * ffbg_init should be run before ffbg().
 */
#define ffbg_init \
	ff_errno = 0; \
	pfd_table = NULL; \
	pid_table = NULL; \
	pfd_table_curpos = 0; \
	pfd_mallocated = 0; \
	pid_mallocated = 0; \
	pfd_count = 0;


/*
 * The ffbg()-macro creates a pipe, adds the receiving end to a dynamically
 * allocated array of other pipes - it does the same thing for it's child
 * PIDs and forks. It immediately returns, keeping the reading end of the
 * pipe open. To execute more functions in the "background", just call ffbg()
 * again. To collect the result from the ffbg()'s, just use ffbg_collect(x) -
 * one call for each ffbg() call. When done, ffbg_free() should be called to
 * free any allocated memory.
 *
 * ff(), ffbg(), ffbg_collect() will set ff_errno == -1 if any kind of error
 * occured, in which case errno would tell about the error.
 *
 * Collecting must be done in the same variable-order as the previous
 * ffbg()'s were called, e.g...
 * 
 * 	unsigned int x;
 * 	unsigned int y;
 * 	unsigned int z;
 * 	ff_data
 *
 * 	ffbg_init
 * 
 * 	ffbg(x, fib, 35);
 * 	ffbg(y, fib, 40);
 * 	ffbg(z, fib, 33);
 * 
 * 	ffbg_collect(x);
 *	printf("x = %u\n", x);
 *
 * 	ffbg_collect(y);
 *	printf("y = %u\n", y);
 *
 * 	ffbg_collect(z);
 *	printf("z = %u\n", z);
 *
 * 	printf("x+y+z = %u\n", x+y+z);
 *
 * In this case function fib() is called as fib(35), fib(40) and fib(33), all
 * in successive order in child processes. fib(40) takes the longest time to
 * process which is why it would be smarter to put that last since fib(33) will
 * be <defunct> until ffbg_collect(z) kicks in and issues a waitpid() for that
 * process. This is generally not an issue, but if you want the most out of
 * your program, put the functions that take the longest execution time as far
 * down in the scheme as possible, e.g...
 *
 * 	ffbg(z, fib, 33);
 * 	ffbg(x, fib, 35);
 * 	ffbg(y, fib, 40);
 * 
 * 	ffbg_collect(z);
 * 	ffbg_collect(x);
 * 	ffbg_collect(y);
 *
 * 	printf("x+y+z = %u\n", x+y+z);
 */
#define ffbg(ret, function, args...) do \
{ \
	int pfd[2]; \
	pid_t pid; \
\
	ff_errno = 0; \
\
	if (!pfd_table) \
	{	if ((pfd_table = malloc(sizeof(int))) == NULL) \
		{	ff_errno = -1; break;	} \
		pfd_mallocated = sizeof(int); \
	} \
	if (!pid_table) \
	{	if ((pid_table = malloc(sizeof(pid_t))) == NULL) \
		{	ff_errno = -1; break;	} \
		pid_mallocated = sizeof(pid_t); \
	} \
\
	if ((pfd_table = realloc(pfd_table, pfd_mallocated+sizeof(int))) == NULL) \
	{	ff_errno = -1; break;	} \
\
	pfd_mallocated += sizeof(int); \
	pfd_table[pfd_table_curpos+1] = -1; \
\
	if ((pid_table = realloc(pid_table, pid_mallocated+sizeof(pid_t))) == NULL) \
	{	ff_errno = -1; break;	} \
	pid_mallocated += sizeof(pid_t); \
	pid_table[pfd_table_curpos+1] = -1; \
\
	if (pipe(pfd) != -1) \
	{ \
		pid = fork(); \
		if (!pid) \
		{ \
			close(pfd[0]); \
			ret = function(args); \
			write(pfd[1], &ret, sizeof(ret)); \
			close(pfd[1]); \
			exit(0); \
		} \
		else if (pid > 0) \
		{ \
			close(pfd[1]); \
			pfd_table[pfd_table_curpos] = pfd[0]; \
			pid_table[pfd_table_curpos] = pid; \
			pfd_table_curpos++; \
		} \
		else \
		{	ff_errno = -1;	} \
	} \
	else \
	{	ff_errno = -1;	} \
} while(0)


/*
 * ffbg_collect() collects (doh) the "return x;"'d value from a previous ffbg()
 * call. Read the description of ffbg() below for usage example.
 */
#define ffbg_collect(ret) do \
{ \
	if (pfd_table[pfd_count] == -1) \
	{	ff_errno = 1; break;	} \
	waitpid(pid_table[pfd_count], NULL, 0); \
	read(pfd_table[pfd_count], &ret, sizeof(ret)); \
	close(pfd_table[pfd_count]); \
	pfd_count++; \
} while(0)


/*
 * Will free any memory that has been allocated by ffbg().
 */
#define ffbg_free() \
{ \
	if (pfd_table) { \
		free(pfd_table); \
		pfd_table = NULL; \
	} \
	if (pid_table) { \
		free(pid_table); \
		pid_table = NULL; \
	} \
}
