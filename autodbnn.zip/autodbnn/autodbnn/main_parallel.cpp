/***************************************************************************
                     Parallel DBNN main.cpp  -  description
                             -------------------
    begin                : Sat Oct 13 11:58:21 IST 2001
    copyright            : (C) 2001 by Ninan Sajeeth Philip
    email                : nsp@stthom.ernet.in
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/*
April 2004 : Version 5.0
This is the MPI version of dbnn. The parallel mode is useful when the test data
is huge.
Nov. 2003 : Version 4.2
Factor Analysis included. The significance of each factor is saved in a 
file <filename>.factor
June 2003 : Version 4.1
DBNN can now be run in automated mode using par files. This is useful for automated
selection of training vectors from a sample of human classified objects. See related
publication.
April 2002 : Version 4.01
DBNN can now determine the number of bins on its own. Array structures changed. You can have
more number of feature vectors and output classes.
Nov. 2001 : Version 2.2
Sept.20th 2001
This is version 2.1 of the DBNN software. The major change here is that a network topology is
considered better over the other by computing the total probability of success when there in no
increase in the number of success counts. rslt orslt prslt changed to floats from integer mode.
A new variable pcnt and pocnt now holds the success counts. The second change is in initializing
the arrays - new c++ in RedHat 7.x require this to avoid segmentation error!

Program to generate anticipation inputs for the training/test set(c)Sajith Philip 1999.
This program is Public Domain. You have all rights to modify and use it. But please acknowledge
the original author and the cite that contains the details of this network.
You may download a technical paper on this network from:
                    
                        http://www.iucaa.ernet.in/~nspp

To run the program, you need an information file and a training and test data set. The format
of these files are explained later in this file.

Enjoy!

Sajith Philip
*/
#include "mpi.h"
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <iostream.h>
#include <stdlib.h>
#include<sys/times.h> // times() fun. is here.
#include <time.h>
// Increase the resolution to improve finer details, provided there is a huge training set.
#define max_resol 1600
#define features 1000
#define classes 1000           // If you get segmentation errors, reduce these values to fit your
//#define oneround 100       //  Memory size.
#define fst_gain 0.9
//***********************************************************************
// List of labels used in the MPI version
double bgain,gain,dmyclass[classes],classval[classes],factor[features],cmax,c2max,tmp2_wts,totprob,oldj;
float vects[features+classes+1],tmpv,max[features],min[features],omax,omin,rslt,rslt2,orslt,orslt2,prslt,nrslt;
clock_t start,stop;
int argfnd, oneround=100,kmax,k2max,ans1,rnn,rnd,i,j,k,l,n,m,c1cnt,c2cnt,pcnt,pocnt,invcnt,innodes,outnodes,resolution[features+1];
char fln[256],fltmp[256],urchoice,urchoicex,bcchoice,savedpar;
FILE *fl1,*fl2,*fl3,*fl4,*fl5,*fl6,*fl7,*fl8,*fl9;
int waiting=1;
int anslbl=1, 
    vectlbl =2, 
    innodeslbl =3,
    outnodeslbl =4,
    dmyclasslbl =5,
    tmpvlbl =6,
    kmaxlbl=7,
    k2maxlbl=8,
    totplbl=9,
    classvlbl=10,
    waitlbl=11,
    sendcnt=0;
double mycombuf[6];    
MPI_Status Stat; 
 int rc,rank,numtasks;
 float locq1,locq2,locinc,fract,range;

//***********************************************************************   
	   int getandsave(int j)
	   {
	    for(i=1;i<j+1;i++)
	    {
	    n++;
	    MPI_Recv(&mycombuf[1],5,MPI_DOUBLE,i,kmaxlbl,MPI_COMM_WORLD,&Stat);
            kmax=(int) mycombuf[1];
	    k2max=(int) mycombuf[2];
	    tmpv = (float) mycombuf[3];
	    totprob = mycombuf[4];
	    classval[kmax]=mycombuf[5];
	    	   
	   fprintf(fl4,"%d  %f \n",n, dmyclass[(int)kmax]);
	   if(ans1 !=3)
	    {
// Factor values
	     fprintf(fl7, "%-8d    %lf   %lf     %lf    ",n,dmyclass[(int)kmax],dmyclass[(int)k2max],tmpv);
	     if(fabs(dmyclass[kmax]-tmpv) > dmyclass[0])
	      {
	       if (classval[kmax]==0.0)
	        {
		   invcnt++;
		   fprintf(fl7, "%-7.4f %% <-Out of range\n",100.0*((classval[kmax])/totprob));
		}
		else
		{
		  if (fabs(dmyclass[k2max]-tmpv) <=dmyclass[0])
		  {
// The Next line defines the margin level required to pick up less confident examples!
		    if ((classval[kmax]-classval[k2max]) > (0.2*totprob/outnodes))
		     {
		      c2cnt++;  // No more differences. NSP (OCT 2001)
		      fprintf(fl7, "%-7.4f %% <-F(1)P(2)\n",100.0*((classval[kmax])/totprob));
		     }
		     else
		     {
		      invcnt++;
		       fprintf(fl7, "%-7.4f %% <-FMC\n",100.0*((classval[kmax])/totprob));
		     }
		  }
		  else
		  {
		     fprintf(fl7, "%-7.4f %% <-Failed\n",100.0*((classval[kmax])/totprob));
		  }
	        }
	      }
	      else
	      {
	       if (classval[kmax] > 1.2*totprob/outnodes)
	       {
	         fprintf(fl7, "%-7.4f %% \n",100.0*((classval[kmax])/totprob));
		 c1cnt++;
	       }
	       else
		{
		  invcnt++;
		  fprintf(fl7, "%-7.4f %% <-PMC\n",100.0*((classval[kmax])/totprob));
		}

	      }
	       fprintf(fl5,"%d %e \n",n,(float) tmpv);
            } // factor != 3
//	    }   // K test
	    }
	    j=1;
	    return j;
	    } 

//***********************************************************************

int main(int argv, char *argp[])
{
/*
 Important note for revision in ver. 4.02
 Compute the bin center of gravities and the Kernel fit that holds the probability to
 find them. The slope of it should be used as bgain for each bin.
*/
/*
 Revision in June 2003
 You can now run dbnn in automated mode by specifying the parameters in 0.par and 1.par
 files. Also dbnn can now use the bin values from the saved apf file.
*/
//printf("Your number of parameters is %d and argp[3] is %c.\n",argv,*argp[3]);

rc=MPI_Init(&argv,&argp);
if (rc !=0)
{
 printf("Error starting MPI code. Exiting\n");
 MPI_Abort(MPI_COMM_WORLD,rc);
 }
 MPI_Comm_size(MPI_COMM_WORLD,&numtasks);
 MPI_Comm_rank(MPI_COMM_WORLD,&rank);
 if(rank==0)
 {
 printf("Please note that only test round has advantage from MPI computation\n");
 printf("I am dividing the job across %d parallel jobs - I am %d\n",numtasks,rank);
}
else
 printf("I am %d out of  %d jobs running on the cluster.\n",rank,numtasks);

 // numtasks define how the range should be divided into.
// printf("Your number of parameters is %d and argp[3] is %c.\n",argv,*argp[3]);
   if(argv > 3)
   {
    argfnd=1;
    if(rank==0)
    cout << "The selected option is " << *argp[3] <<"\n";    
    switch(*argp[3])
    {
    case '0':
    
    ans1=0;
    if((fl2=fopen("0.par","r"))!=NULL)
     {
      fscanf(fl2,"%c\n",&bcchoice);
      fscanf(fl2,"%c\n",&urchoice);
      fscanf(fl2,"%c\n",&savedpar);
      fscanf(fl2,"%c\n",&urchoicex);
      fclose(fl2);			
      }
      else
     { cout << "No Parameter File... existing..";
     exit(1);
     }
    break;
    case '1':
   
    ans1=1;
    if((fl2=fopen("1.par","r"))!=NULL)
     {
      fscanf(fl2,"%lf",&gain);
      fscanf(fl2,"%d",&oneround);
      fclose(fl2);			
     }
     else
     { cout << "No Parameter File... existing..";
     exit(1);
     }
    break;
    case '2':
    
    ans1=2;
    break;

    case '3':
    
    ans1=3;
    break;
    
    case '4':
    
    ans1=0;
   if((fl2=fopen("0.par","r"))!=NULL)
     {
      fscanf(fl2,"%c\n",&bcchoice);
      fscanf(fl2,"%c\n",&urchoice);
      fscanf(fl2,"%c\n",&savedpar);
      fscanf(fl2,"%c\n",&urchoicex);
      fclose(fl2);			
      }
      else
     { cout << "No Parameter File... existing..";
     exit(1);
     }
    break;
    
    default:

     cout << "Create the APF file(0) or Create the Weights file (1) or Classify Data(2,3) ?";
     cin >> ans1;
     break;
    }
    }
    else
    {
     argfnd=0;
     cout << "Create the APF file(0) or Create the Weights file (1) or Classify Data(2,3) ?";
     cin >> ans1;
    }
    if(ans1 == 2)
     {
     if(argfnd==1)
     bgain=0.0;
     else
     {
     cout << "Allowed relaxation on the boundary (in % use 0 for default from training data) :";
     cin >> bgain;
//     if (bgain < 0) bgain = 0;
     bgain=bgain*1.0;
     }
     }
     else
     bgain= 0;  // During training we are strict on boundary constraints.

    if(*strcpy(fltmp,argp[1])=='\0')
     {
     cout << "Enter the name of the input file without extension :";
     cin >> fln;
     //scanf ("%s",&fln);
     }
     else
     {
     strcpy(fln,argp[1]);
     }
     strcpy(fltmp,fln);
     strcat(fltmp,".dat");
/*
  The structure of the data file is:
  Feature1 Feature2 Feature3 ....(etc upto innodes) ActualClass
  Feature1 Feature2 Feature3 ....(etc upto innodes) ActualClass
  Feature1 Feature2 Feature3 ....(etc upto innodes) ActualClass
  The delimiters are spaces and not tabs!!
*/
    if((fl1=fopen(fltmp,"r"))!=NULL)
     {
	    strcpy(fltmp,fln);
	    strcat(fltmp,".inf");
/*
  The format of the info file is: (in each line enter)
  innodes
  outnodes
  margin   <- This addition is required for regression problems.
  1.0       <- You can give any real positive value here. It is just a label.
  2.0
  ... (etc. upto no of classes)
*/	
     	if((fl2=fopen(fltmp,"r"))!=NULL)
	    {
		 i=0;
		 fscanf(fl2,"%d",&innodes);
		 fscanf(fl2,"%d",&outnodes);
		 for (i=0;i<=outnodes;i++) // dmyclass[0] contains margin others are expected values.
		 fscanf(fl2,"%lf",&dmyclass[i]);
			
	    }
	    else
	    {
		 cout << "Unable to find the Info file. Exiting !!";
		 exit(1);
	    }
  
     } // program ends.
     else   // data file read error.
     {
      cout << "Unable to open the data file";
      exit(1);
      }
      gain=2.0;
 /**************** Let us Define the Network Structure *********************************/
 double(* TabLookUp);
 TabLookUp = new double[int(max_resol)+4];
 if(TabLookUp==NULL){cout << "Out of Memory to Run Code at TabLookUp.. Exiting\n";exit(1);}
 int (* anti_net)[max_resol+1][outnodes+1];
 anti_net  = new int[innodes+1][max_resol+1][outnodes+1]; // Our Network
 if(anti_net==NULL){cout << "Out of Memory to Run Code at anti_net.. Exiting\n";exit(1);}
 double (* anti_wts)[max_resol+1][outnodes+1];
 anti_wts  = new double[innodes+1][max_resol+1][outnodes+1]; // Connection wts.
 if(anti_wts==NULL){cout << "Out of Memory to Run Code at anti_wts.. Exiting\n";exit(1);}
 double (* antit_wts)[max_resol+1][outnodes+1];
 antit_wts = new double[innodes+1][max_resol+1][outnodes+1]; // Temp. storage
 if(antit_wts==NULL){cout << "Out of Memory to Run Code at antit_wts.. Exiting\n";exit(1);}
 double (* antip_wts)[max_resol+1][outnodes+1];
 antip_wts = new double[innodes+1][max_resol+1][outnodes+1]; // Temp. last best.
 if(antip_wts==NULL){cout << "Out of Memory to Run Code at antip_wts.. Exiting\n";exit(1);}
 int (* classtot)[max_resol+1];
 classtot  = new int[innodes+1][max_resol+1];           // Total Prob. computed
 if(classtot==NULL){cout << "Out of Memory to Run Code at classtot.. Exiting\n";exit(1);}
 int (* mask_min)[max_resol+1][innodes+1][outnodes+1];
 mask_min  = new int[innodes+1][max_resol+1][innodes+1][outnodes+1]; // Min Threshold
 if(mask_min==NULL){cout << "Out of Memory to Run Code at mask_min.. Exiting\n";exit(1);}
 int (* mask_max)[max_resol+1][innodes+1][outnodes+1];
 mask_max  = new int[innodes+1][max_resol+1][innodes+1][outnodes+1]; // Max Threshold
 if(mask_max==NULL){cout << "Out of Memory to Run Code at mask_max.. Exiting\n";exit(1);}
 double (* binrec)[4][outnodes+1];
 binrec = new double[innodes+1][4][outnodes+1]; // Bin records here.
 if(binrec==NULL){cout << "Out of Memory to Run Code at binrec.. Exiting\n";exit(1);}
 // We define the bin locations for each vector here
 double (* tbinrec)[4][outnodes+1];
 tbinrec = new double[innodes+1][4][outnodes+1]; // Bin records here.
 if(tbinrec==NULL){cout << "Out of Memory to Run Code at tbinrec.. Exiting\n";exit(1);}
 double (* binloc)[max_resol+1];
 binloc = new double [innodes+1][max_resol+1];
 if(binloc==NULL){cout << "Out of Memory to Run Code at binloc.. Exiting\n";exit(1);}
 
 
  /***************************Let us put up the Network***********************************/
 for(i=0;i<=(max_resol+2);i++) TabLookUp[i]= (double)(1.0*i/max_resol); // We will set it to exact values later.
        for(i=0;i<=innodes;i++)
	      for(j=0;j< 3;j++)
	      for(k=0;k<=outnodes;k++)
	      {	   
	      binrec[i][j][k]=-1.0;
	      }
//  cout << "Ok. Here" << "\n\n";

	      for(i=0;i<=innodes;i++)
	      for(j=0;j<=resolution[i];j++)
	      for(k=0;k<=outnodes;k++)
	      {
	      anti_net[i][j][k]=1;
	      anti_wts[i][j][k]=(double)(1.0);
	      binloc[i][j]=-1.0;
	      }
              for(i=0;i<=innodes;i++)
	       for(j=0;j<=resolution[i];j++)
	       for(l=0;l<=innodes;l++)
	     for(k=0;k<=classes;k++)
	      {
	      classtot[i][j]=0;
	      mask_min[i][j][l][k]=-1;
	      mask_max[i][j][l][k]=-1;
	      }
 	      
//    Start the counter for case 2 here.................
             start = times(NULL);
             if (ans1==0)
	    {
            if(rank ==0)
            {
	      n=0;
	      omax=-400;
	      omin=400;
	      while (!feof(fl1))
	      {
		 for(i=1;i<=innodes;i++)
		 if (n==0)
		 {
		   fscanf(fl1,"%f",&vects[i]);
		   min[i]=vects[i];
		   max[i]=vects[i];
		 }
		 else
		 {
		   fscanf(fl1,"%f",&vects[i]);
		   if( vects[i]> max[i]) max[i]=vects[i];
		   if (min[i] > vects[i]) min[i]=vects[i];
		 }
		 fscanf(fl1,"%f\n",&tmpv);
		 if(tmpv>omax) omax = tmpv;
                 if(tmpv<omin) omin =tmpv;
		 k=1;
		 j=1;
		 while ((fabs(tmpv - dmyclass[k])) > dmyclass[0]) k++;
                 for(i=1;i<=innodes;i++)
		 {
		 if(binrec[i][j][k] == -1.0)
		  binrec[i][j][k]=(double)vects[i];
		 
		 if(binrec[i][j+1][k] == -1.0)
		  binrec[i][j+1][k]=(double)vects[i];
		 
		 if(binrec[i][j][k] > vects[i]) binrec[i][j][k]=(double)vects[i];
		 if(binrec[i][j+1][k] < vects[i]) binrec[i][j+1][k]=(double)vects[i];
   	 }
		 n++;
	      }
	      cout << "No of vectors =" << n <<" and i/n is= " << 1.0/n << "\n";

 // *****************************************************************************
  // We will now rescale all bin values to fall between zero and one.

     for(i=1;i<=innodes;i++)
     for(k=1;k<=outnodes;k++)
     {
      binrec[i][1][k]=(float)(binrec[i][1][k]-min[i])/(max[i]-min[i]);
      binrec[i][2][k]=(float)(binrec[i][2][k]-min[i])/(max[i]-min[i]);
     }

 //******************************************************************************
  /*
      For each feature we assign 'n' number of bins to catch the details. This is what we mean
      by resolution. Start with low values for better generalization features of the network.
      Larger value will however help you to resolve the finer details. The moral is that the
      exact value has to be computed by trial and error.
  */
   if(argfnd==0)
   {
   cout << " Do you want to consider the centroids as the bin centers ? ";
   cin >> bcchoice;
   }
   if ((bcchoice =='y') || ( bcchoice=='Y'))
   {
// First identify initial bin margins

        for(i=1;i<=innodes;i++) resolution[i]=2*outnodes;
	      for(i=1;i<=innodes;i++)
	      for(j=1;j<=2*outnodes;j++)
	      binloc[i][j]=-1.0;                 /// Let us reset the bins first.
	      for(i=1;i<=innodes;i++)
	      for(k=1;k<=outnodes;k++)
	      {
       if((binloc[i][1] == -1) &&(binloc[i][2] == -1))
	      { binloc[i][1]=binrec[i][1][k];
	      if(binrec[i][1][k] != binrec[i][2][k])
	      binloc[i][2]=binrec[i][2][k];
	      }
	      else
	      {
	      j=1;
	      while (((binloc[i][j] < binrec[i][1][k]) && (binloc[i][j] != -1))) j++;
	      if (j > 2*outnodes) cout << "Warning J exceeds limit J= " << j << "\n";
	      if((binloc[i][j] == -1) &&(binloc[i][j+1] == -1))
	      {
	      binloc[i][j]=binrec[i][1][k];
	      if(binrec[i][1][k] != binrec[i][2][k])
	      binloc[i][j+1]=binrec[i][2][k];
	      }
	      else
	      {
	     if(binloc[i][j] == -1)
	      binloc[i][j]=binrec[i][1][k];
	     else
	     {
	     if((binloc[i][j] > binrec[i][1][k])&&(binrec[i][1][k] !=-1))
	      {
	      l=j;
	      while(binloc[i][l] != -1) l++;
	      while(l >j)
	      {
	      if (l > 2*outnodes) cout << "Warning l exceeds limit l= " << l << "\n";
	      binloc[i][l] =binloc[i][l-1];
	      l--;
	      }
	      binloc[i][j]=binrec[i][1][k];
	      }
	      }
	      }
	      if((binrec[i][2][k] != binrec[i][1][k])&&(binrec[i][2][k] !=-1))
	      {
	      j=1;
	      while (((binloc[i][j] < binrec[i][2][k]) && (binloc[i][j] != -1))) j++;
	      if (j > 2*outnodes) cout << "Warning J exceeds limit j= " << j << "\n";
	       if(binloc[i][j] == -1)
	        binloc[i][j]=binrec[i][2][k];
	      else
	     if((binloc[i][j] > binrec[i][2][k])&&(binrec[i][2][k] !=-1))
	      {
	      l=j;
	      while(binloc[i][l] != -1) l++;
	      while(l >j)
	      {
	      if (l > 2*outnodes) cout << "Warning l exceeds limit l= " << l << "\n";
	      binloc[i][l] =binloc[i][l-1];
	      l--;
	      }
	      binloc[i][j]=binrec[i][2][k];
	      }
	      }
	      }
	      }
	    for(i=1;i<=innodes;i++)
              resolution[i]=-1;
	    for(i=1;i<=innodes;i++)
	     for(j=1;j<=2*outnodes;j++)
	      if (binloc[i][j] > -1) resolution[i]++;

// We will now try to identify the centroids of each classes in the bins and relocate
// them as the binlocations in our model.
      rewind(fl1);
 	      for(i=1;i<=innodes;i++)
	      for(j=0;j<=2;j++)
	      for(k=1;k<=outnodes;k++)
	        anti_net[i][j][k]=1;           // We count the lowest/highest twice since we
                                         // Start with it as the default.
                                         // Keep track of the counts here.

        for(i=1;i<=innodes;i++)
	       for(k=1;k<=outnodes;k++)
	      {	
	      tbinrec[i][1][k]=binrec[i][1][k];   // Let us save our starting points.
	      tbinrec[i][2][k]=binrec[i][2][k];   // Let us save our starting points.
	     }

     while (!feof(fl1))
	      {
		 for(i=1;i<=innodes;i++)
       {
		   fscanf(fl1,"%f",&vects[i]);
       vects[i]= (vects[i]-min[i])/(max[i]-min[i]);   // Scale all inputs from 0 to 1
       }
			 fscanf(fl1,"%f\n",&tmpv);
      k=1;
 	 while ((fabs(tmpv - dmyclass[k])) > dmyclass[0]) k++;
    for(i=1;i<=innodes;i++)
		 {
     j=1;
	   while ((j <= resolution[i]) && (binloc[i][j] < binrec[i][1][k])) j++;      // Track our starting point.
      if (binloc[i][j] != binrec[i][1][k]) cout << "ERROR: J = " << j << " Bin location [" << binrec[i][1][k] << "] could not be detected \n";
 		 if((binloc[i][j] <= vects[i]) &&(binloc[i][j+1] > vects[i]))
        { tbinrec[i][1][k]+=(double)vects[i];
           anti_net[i][1][k]++;
         }
		  else                                         // All the rest belongs to the other group.
        { tbinrec[i][2][k]+=(double)vects[i];
           anti_net[i][2][k]++;
         }
		  }
		
	   }      // end of file.


	   for(i=1;i<=innodes;i++)
	      for(k=1;k<=outnodes;k++)
	      {	
        if (anti_net[i][1][k] > 0)
	      binrec[i][1][k]= tbinrec[i][1][k]/anti_net[i][1][k];
        if (anti_net[i][2][k] > 0)
	      binrec[i][2][k]= tbinrec[i][2][k]/anti_net[i][2][k];

// Reset everything back to normal

 	      for(i=0;i<=innodes;i++)
	      for(j=0;j<=resolution[i];j++)
	      for(k=0;k<=outnodes;k++)
	      {
	      anti_net[i][j][k]=1;
	      anti_wts[i][j][k]=(double)(1.0);
	      binloc[i][j]=-1.0;
	      }



     }
/***********************************************************************************/
   }  // bcchoice done

   //     urchoice =' ';
          if(argfnd==0)
            {
             while ((urchoice != 'Y') && (urchoice != 'N'))
             {
              cout << "Do you Want ME to determine the bin sizes (Y/N)?";
	      cin >> urchoice;
              }
              
	      if (urchoice == 'y') urchoice='Y';
	      else
	      if(urchoice == 'n') urchoice='N';
            }
	      if((urchoice == 'Y') || (urchoice=='y'))
	      {
	      cout << "In Auto mode, the maximum resolution is always twice the number of classes\n";
	      for(i=1;i<=innodes;i++) resolution[i]=2*outnodes;
	      for(i=1;i<=innodes;i++)
	      for(j=1;j<=2*outnodes;j++)
	      binloc[i][j]=-1.0;           /// Let us reset the bins first.
	      for(i=1;i<=innodes;i++)
	      for(k=1;k<=outnodes;k++)
	      {
             if((binloc[i][1] == -1) &&(binloc[i][2] == -1))
	      { binloc[i][1]=binrec[i][1][k];
	      if(binrec[i][1][k] != binrec[i][2][k])
	      binloc[i][2]=binrec[i][2][k];
	      }
	      else
	      {
	      j=1;
	      while (((binloc[i][j] < binrec[i][1][k]) && (binloc[i][j] != -1))) j++;
	      if (j > 2*outnodes) cout << "Warning J exceeds limit J= " << j << "\n";
	      if((binloc[i][j] == -1) &&(binloc[i][j+1] == -1))
	      {
	      binloc[i][j]=binrec[i][1][k];
	      if(binrec[i][1][k] != binrec[i][2][k])
	      binloc[i][j+1]=binrec[i][2][k];
	      }
	      else
	      { 
	     if(binloc[i][j] == -1)
	      binloc[i][j]=binrec[i][1][k];
	     else
	     {
	     if((binloc[i][j] > binrec[i][1][k])&&(binrec[i][1][k] !=-1))
	      {
	      l=j;
	      while(binloc[i][l] != -1) l++;
	      while(l >j)
	      {
	      if (l > 2*outnodes) cout << "Warning l exceeds limit l= " << l << "\n";
	      binloc[i][l] =binloc[i][l-1];
	      l--;
	      }
	      binloc[i][j]=binrec[i][1][k];
	      }
	      }
	      }
	      if((binrec[i][2][k] != binrec[i][1][k])&&(binrec[i][2][k] !=-1))
	      {
	      j=1;
	      while (((binloc[i][j] < binrec[i][2][k]) && (binloc[i][j] != -1))) j++;
	      if (j > 2*outnodes) cout << "Warning J exceeds limit j= " << j << "\n";
	       if(binloc[i][j] == -1)
	        binloc[i][j]=binrec[i][2][k];
	      else
	     if((binloc[i][j] > binrec[i][2][k])&&(binrec[i][2][k] !=-1))
	      {
	      l=j;
	      while(binloc[i][l] != -1) l++;
	      while(l >j)
	      {
	      if (l > 2*outnodes) cout << "Warning l exceeds limit l= " << l << "\n";
	      binloc[i][l] =binloc[i][l-1];
	      l--;
	      }
	      binloc[i][j]=binrec[i][2][k];
	      }
	      }
	      }
	      }
	    for(i=1;i<=innodes;i++)
              resolution[i]=-1;
	    for(i=1;i<=innodes;i++)
	     for(j=1;j<=2*outnodes;j++)
	      if (binloc[i][j] > -1) resolution[i]++;

  // We will now rescale everything to the bin numbers

	     for(i=1;i<=innodes;i++)
	     for(j=1;j<=2*outnodes;j++)
	 	binloc[i][j]=(double)(binloc[i][j]*resolution[i]);

	      }  // uchoice ==Y
	      else
	      {
              if(argfnd==0)
              {
	      cout <<"Do you want to use the saved parameters (Y/N)? ";
	      cin >>savedpar;
              }
	      if (savedpar == 'y') savedpar='Y';
	      else
	      if(savedpar == 'n') savedpar='N';
	      if((savedpar == 'Y') || (savedpar=='y'))
	      {
	       strcpy(fltmp,fln);
	       strcat(fltmp,".apf");
	       fl2=NULL;
	       if((fl2=fopen(fltmp,"r"))!=NULL)
	        {
	        cout << "Reading from the saved information\n";
	   	for (i=1;i<=innodes;i++)
		{
		fscanf(fl2,"%d",&resolution[i]);
                for(j=0;j<=resolution[i];j++) binloc[i][j+1]=j*1.0;
		//cout << resolution[i] <<"\n";
	        }
		cout << innodes << " itemes read from " << fltmp <<"\n";
		}
		else
		{
		cout << "ERROR: File " << fltmp << " not found" << "\n";
		exit(1);
		}
	//	fclose(fl2);
	      }
	      else
	      for(i=1;i<=innodes;i++)
	      {
                cout << "Enter the resolution required for node " << i << "[" << max_resol << "] (1 to " << max[i]-min[i] << "): ";
                cin >> resolution[i];
                for(j=0;j<=resolution[i];j++) binloc[i][j+1]=j*1.0;
	      }
	      } // urchoice ends here.
	      for(i=0;i<=innodes;i++)
	      for(j=0;j<=resolution[i];j++)
	      for(k=0;k<=outnodes;k++)
	      {
	      anti_net[i][j][k]=1;
	      anti_wts[i][j][k]=(double)(1.0);
	      }
	      // Start the counter now...............
	      start = times(NULL);
              for(i=0;i<=innodes;i++)
	       for(j=0;j<=resolution[i];j++)
	       for(l=0;l<=innodes;l++)
	     for(k=0;k<=classes;k++)
	      {
	      mask_min[i][j][l][k]=-1;
	      mask_max[i][j][l][k]=-1;
	      }
	     rewind(fl1);
	      while (!feof(fl1))
	      {
	        for (i=1;i<=innodes;i++) fscanf(fl1,"%f",&vects[i]);
	 	fscanf(fl1,"%f\n",&tmpv);
	 	for(i=1;i<=innodes;i++)
	 	vects[i]=(float)(vects[i]-min[i])/(max[i]-min[i])*resolution[i];
	 	for (i=1;i<=innodes;i++)
	 	{
		  j=0;
	     	  k=1;
	     	  l=0;
                 oldj=(double)2*resolution[i];
                  while (fabs(vects[i]-binloc[i][j+1]) < oldj)
                  {
                  oldj=fabs(vects[i]-binloc[i][j+1]);
                  j++;
                  }
                  j--;
		  k=1;
		  while ((fabs(tmpv - dmyclass[k])) > dmyclass[0]) k++;
		   (anti_net[i][j][k])++;
        	  for (l=1;l<=innodes;l++)
              {
       	  if(mask_min[i][j][l][k] ==-1)
        	  { m=0;
		  while(vects[l] > resolution[l]*TabLookUp[m] ) m++;
		  if((m<0)||(vects[l]==0)) m=0;
		  mask_min[i][j][l][k]=m;
        	  }
        	  else
        	  if(resolution[l]*TabLookUp[mask_min[i][j][l][k]] > vects[l])
        	  { m=mask_min[i][j][l][k];
		  while(resolution[l]*TabLookUp[m] > vects[l]) m--;
		  if((m<0)||(vects[l]==0)) m=0;
		  mask_min[i][j][l][k]=m;
       	  }
        	  if(mask_max[i][j][l][k] ==-1)
        	  { m=0;
		  while( vects[l] > resolution[l]*TabLookUp[m]  ) m++;
		  mask_max[i][j][l][k]=m;  // Allow some tolerance
        	  }
        	  else
        	  if(resolution[l]*TabLookUp[mask_max[i][j][l][k]] < vects[l])
        	  { m=mask_max[i][j][l][k];
		  while( resolution[l]*TabLookUp[m] < vects[l] ) m++; // track upper limit
		  mask_max[i][j][l][k]=m;   // Allow some tolerance
        	  }
        	  }
   	 //	  cout << "-----------------------------------------------------\n";
		  }
	      }
	      fclose(fl1);
	      fclose(fl2);
 if(argfnd==0)
 {              
 cout << "Do you want me to maximize the boundaries ?";
 cin >> urchoicex;
 }
 if((urchoicex == 'Y') || (urchoicex=='y'))
   {
/* We will now modify the mask min and maximas to their optimal values
 May 2002*/
      for(i=1;i<innodes;i++)
      for(j=0;j<=resolution[i];j++)
      for(l=1;l<innodes; l++)
      for(k=1;k<=outnodes;k++)
      { kmax= mask_min[i][j][l][1];
        cmax = 0;
        for(m=1;m<=outnodes;m++)
        {
        if(mask_max[i][j][l][k] >= 0)
        if((mask_max[i][j][l][k]< mask_min[i][j][l][m])&&(mask_min[i][j][l][m] < kmax))
         {
          kmax=mask_min[i][j][l][m];
          cmax=m;
         }


        }
        if(cmax >0)
         {
          mask_max[i][j][l][k] = ((mask_max[i][j][l][k]+kmax)/2);
          mask_min[i][j][l][int(cmax)]= mask_max[i][j][l][k];
         }
      }
   } //urchoice ends here.
//********************************************************************
	      // Create classtot values ***********************
	      for(i=1;i<=innodes;i++)for(j=0;j<=resolution[i];j++) classtot[i][j]=0;
	      for(i=1;i<=innodes;i++)
	      for(j=0;j<=resolution[i];j++)
	      for(k=1;k<=outnodes;k++) classtot[i][j]+= (anti_net[i][j][k]);
	    // *************************************************
         /*
            The conditional Probability,
	    P(A|B) = P(A intersection B)/P(B) is the
	    probability for the occurance of A(k) if B(ij) has happened =
	    Share of B(ij) that is held by A(k) / Probability of total B(ij)
	    in that particular feature i with resolution j.

                      */
              strcpy(fltmp,fln);
	      strcat(fltmp,".awf");      // This file holds the weights
	      fl6=fopen(fltmp,"w+");
	      strcpy(fltmp,fln);
	      strcat(fltmp,".apf");     // This file holds the estimated probability
	      if((fl1=fopen(fltmp,"w+"))!=NULL)
	      {
		 for(i=1;i<=innodes;i++) fprintf(fl1,"%d ",resolution[i]);
		 fprintf(fl1,"\n%f %f \n",omax,omin);
		 for(i=1;i<=innodes;i++) fprintf(fl1,"%f ",max[i]);
		 fprintf(fl1,"\n");
		 for(i=1;i<=innodes;i++) fprintf(fl1,"%f ",min[i]);
		 fprintf(fl1,"\n");
		 for(i=1;i<=innodes;i++)
		 {
		   for(j=0;j<=resolution[i];j++)
		   {
			 for(k=1;k<=outnodes;k++)
			 {
			 fprintf(fl1,"%d ",anti_net[i][j][k]);
			 fprintf(fl6,"%f ",anti_wts[i][j][k]);
			 }
			 fprintf(fl6,"\n");
			 fprintf(fl1,"\n");
		   }
		   fprintf(fl6,"\n");
	       fprintf(fl1,"\n");
		 }
		  for(i=1;i<=innodes;i++)
		  {
		  for(l=0;l<=resolution[i];l++)
		  for(j=1;j<=innodes;j++)
		  for(k=1;k<=outnodes;k++)
		  {
		    fprintf(fl6,"%d %d ",mask_min[i][l][j][k],mask_max[i][l][j][k]);
		  }
		  fprintf(fl6,"\n");
		  }
	   }
	      else
	      {
		 cout << "Unable to create file for output\n";
		 exit(1);
	      }
              for(i=1;i<=innodes;i++)
	      for(j=1;j<=resolution[i]+1;j++)
	      fprintf(fl6,"%lf\n", (double)binloc[i][j]);                 /// Let us print the bins.
	      fclose(fl1);
	      fclose(fl6);
	      fflush(NULL);
	      cout << "Creating the Anticipated Weights data file\n";
	   } //rank ==0 for case 0 ends here.
	   } 
/**********************************End of Case 0 ******************************/
if(ans1==1)
{
   if(rank==0)
   {
    start = times(NULL);
    pcnt=0;
    pocnt=0;
    rslt=0.0;
    rslt2=0.0;
    orslt=rslt;
    orslt2=rslt2;
    cout << "The programe will now modify the compensatory weights\n";
    if(argfnd==0)
    {
    cout << "Please enter the gain:";
    cin >> gain;
    cout << "Please enter the number of training epochs:";
    cin >> oneround;
    }
    // Start the counter in this round here...................
    start = times(NULL);
    strcpy(fltmp,fln);
	strcat(fltmp,".awf");
	fl6=fopen(fltmp,"r");
	strcpy(fltmp,fln);
	strcat(fltmp,".apf");
	fl2=NULL;
	if((fl2=fopen(fltmp,"r"))!=NULL)
    {
			for (i=1;i<=innodes;i++) fscanf(fl2,"%d",&resolution[i]);
			fscanf(fl2,"\n%f",&omax);
			fscanf(fl2,"%f",&omin);
			fscanf(fl2,"\n");
		    for(i=1;i<=innodes;i++) fscanf(fl2,"%f",&max[i]);
		    fscanf(fl2,"\n");
	      	for(i=1;i<=innodes;i++) fscanf(fl2,"%f",&min[i]);
		 	fscanf(fl2,"\n");
		 	for(i=1;i<=innodes;i++)
		 	{
			  for(j=0;j<=resolution[i];j++)
			  {
				 for(k=1;k<=outnodes;k++)
				 {
				 fscanf(fl2,"%d",&anti_net[i][j][k]);
				 fscanf(fl6,"%lf",&anti_wts[i][j][k]);
				 antit_wts[i][j][k]=anti_wts[i][j][k];
				 antip_wts[i][j][k]=anti_wts[i][j][k];
				 }
				 fscanf(fl2,"\n");
				 fscanf(fl6,"\n");
			  }
			  fscanf(fl2,"\n");
	                  fscanf(fl6,"\n");
	       }
	  	   for(i=1;i<=innodes;i++)
	  	   {
	  	   for(l=0;l<=resolution[i];l++)
	  	   for (j=1;j<=innodes;j++)
		   for(k=1;k<=outnodes;k++)
		   {
		     fscanf(fl6,"%d",&mask_min[i][l][j][k]);
		     fscanf(fl6,"%d",&mask_max[i][l][j][k]);
		   }
		   fscanf(fl6,"\n");
		   }
  	      for(i=1;i<=innodes;i++)
	      for(j=1;j<=resolution[i]+1;j++)
	      fscanf(fl6,"%lf\n", &binloc[i][j]);                 /// Let us print the bins.
         	   }
       else
	   {
 	 	cout << "Unable to Open the APF information file\n";
		exit(1);
	}
  	      fclose(fl2);
	fclose(fl6);
      // Create classtot values ***********************
	      for(i=1;i<=innodes;i++)for(j=0;j<=resolution[i];j++) classtot[i][j]=0;
	      for(i=1;i<=innodes;i++)
	      for(j=0;j<=resolution[i];j++)
	      for(k=1;k<=outnodes;k++) classtot[i][j]+= (anti_net[i][j][k]);
            // *************************************************
   for(rnd=0;rnd<=oneround;rnd++)     // Training round starts here....
    {
       strcpy(fltmp,fln);
       strcat(fltmp,".dat");
       fl1=fopen(fltmp,"r");
  	   n=0;
       rslt=0.0;
       rslt2=0.0;
       pcnt=0;
     	       while (!feof(fl1))
	   {
	      n++;
	      for (i=1;i<=innodes;i++) fscanf(fl1,"%f",&vects[i]);
	      fscanf(fl1,"%f\n",&tmpv);
	      for(i=1;i<=innodes;i++)
	      vects[i]=(vects[i]-min[i])/(max[i]-min[i])*resolution[i];
//****************************************************************************	      
		  for (i=1;i<=innodes;i++)
		  {
		      j=0;
	          k=1;
	         oldj=(double)2*resolution[i];
                  while (fabs(vects[i]-binloc[i][j+1]) < oldj)
                  {
                  oldj=fabs(vects[i]-binloc[i][j+1]);
                  j++;
                  }
                  j--;
          for (k=1;k<=outnodes;k++)
		      {
                       tmp2_wts=(double)anti_net[i][j][k]/classtot[i][j];
		         for(l=1;l<=innodes;l++)
			      {
             if(mask_min[i][j][l][k] < 0)tmp2_wts=tmp2_wts*fst_gain;
             else
	   		     if((double)resolution[l]*TabLookUp[mask_min[i][j][l][k]] > vects[l])
			        tmp2_wts=tmp2_wts*fst_gain;
             if(mask_max[i][j][l][k] < 0)tmp2_wts=tmp2_wts*fst_gain;
             else
			       if(vects[l] > (double)resolution[l]*TabLookUp[mask_max[i][j][l][k]])
			        tmp2_wts=tmp2_wts*fst_gain;
			      }
	          if(i==1) classval[k]=tmp2_wts*anti_wts[i][j][k];
	          else
	           classval[k]*=(double)tmp2_wts*anti_wts[i][j][k];
	         }

		   }
		   kmax=0;
		   cmax=0;
		   for (k=1;k<=outnodes;k++)
		   {
		      if (classval[k] > cmax)
		      {
			   cmax=classval[k];
			   kmax=k;
		      }
		   }
//*****************************----------------------------********************************		   
		   if ((fabs(dmyclass[kmax]-tmpv) > dmyclass[0]) && (rnd >0))
	       {
	          for (i=1;i<=innodes;i++)
	          {
		        j=0;
	            k=1;
                  oldj=(double)2*resolution[i];
                  while (fabs(vects[i]-binloc[i][j+1]) < oldj)
                  {
                  oldj=fabs(vects[i]-binloc[i][j+1]);
                  j++;
                  }
                  j--;
	          while (fabs(dmyclass[k]-tmpv) > dmyclass[0]) k++;
		   {
		        anti_wts[i][j][k]+=(double)gain*(1.0-(classval[k]/classval[(int)kmax]));
			if(anti_wts[i][j][k] < 0.0)
			cout << k << " "<< tmpv << "[" << dmyclass[1] << "]" << dmyclass[outnodes] << "\n";
                   }
			
	         }
	      } // kmax check
//*****************************---------------------------*********************************		 
		 } // while not eof check
		 // Now save the wieights
		 fclose(fl1);
	  strcpy(fltmp,fln);
       strcat(fltmp,".dat");
       fl1=fopen(fltmp,"r");
  	   n=0;
       rslt=0.0;
       rslt2=0.0;
       pcnt=0;
       while (!feof(fl1))                    // Test round...
	   {
	      n++;
	      kmax=0;
		    cmax=0;
		    for (i=1;i<=innodes;i++) fscanf(fl1,"%f",&vects[i]);
	      fscanf(fl1,"%f\n",&tmpv);
	      for(i=1;i<=innodes;i++)
              {
	      vects[i]=(vects[i]-min[i])/(max[i]-min[i])*resolution[i];
              if (vects[i] < 0) vects[i]=0;             // let us be bounded. #Oct 2001.
              if(vects[i] > resolution[i]) vects[i]=resolution[i];
              }
		  for (i=1;i<=innodes;i++)
		  {
		      j=0;
	          k=1;
                  oldj=(double)2*resolution[i];
                  while (fabs(vects[i]-binloc[i][j+1]) < oldj)
                  {
                  oldj=fabs(vects[i]-binloc[i][j+1]);
                  j++;
                  }
                  j--;
	           for (k=1;k<=outnodes;k++)
		      {

		       tmp2_wts=(double)anti_net[i][j][k]/classtot[i][j];
		       for(l=1;l<=innodes;l++)
			     {
          if(mask_min[i][j][l][k] < 0)tmp2_wts=tmp2_wts*fst_gain;
          else
	   		  if(( vects[l] < (double)resolution[l]*TabLookUp[mask_min[i][j][l][k]])||(vects[l] > (double)resolution[l]*TabLookUp[mask_max[i][j][l][k]]))
              tmp2_wts=tmp2_wts*fst_gain;

           }
		        if(i==1) classval[k]=tmp2_wts*anti_wts[i][j][k];
	            else
		        classval[k]*= (double)tmp2_wts*anti_wts[i][j][k];
		      }
		   }
		 	 for (k=1;k<=outnodes;k++)
		   {
	       if (classval[k] > cmax)
		     {
		       cmax=classval[k];
		       kmax=k;
		     }
        }
        if (fabs(dmyclass[kmax]-tmpv) <= dmyclass[0])
		   {
	            rslt2+=cmax;
		     pcnt++;
		   }
	     else
		   {
		   k=1;
	           while (fabs(dmyclass[k]-tmpv) > dmyclass[0]) k++;
	           rslt+=cmax-classval[k];
		    }
		 } // while not eof check
		 // Now save the wieights
		 fclose(fl1);
	     kmax=0;
	    // if((orslt2 < rslt2)&&(orslt< rslt)||(pcnt>pocnt))
              if(orslt2==0) orslt2=rslt2;
              if(orslt==0) orslt=rslt;
	      prslt=(rslt2-orslt2);
	      nrslt=(orslt/rslt);
             // prslt>0.0 ||
	      if(pcnt>pocnt) // || (prslt>0.0 && nrslt>1.0)) April.2002
	     {
	       rnn=rnd;
	       pocnt=pcnt;   // The best result is now saved in pocnt
	       for(i=1;i<=innodes;i++)
	       {
	           for(j=0;j<=resolution[i];j++)
		    {
		      for(k=1;k<=outnodes;k++)
		      {
		      antip_wts[i][j][k]=antit_wts[i][j][k];
		      antit_wts[i][j][k]=anti_wts[i][j][k];
	              }
		    }
	       }
	       cout << "Round:" << rnn << "| TProb["<<prslt<<"," <<nrslt<<"] | Passed count:" << pocnt << endl;
	       if(orslt2 <rslt2) orslt2=rslt2;
	       if(rslt < orslt) orslt=rslt;
	     }
	    // prslt=rslt+rslt2;
	 }  //rnd inc.
	 strcpy(fltmp,fln);
	 strcat(fltmp,".awf");
	 fl6=fopen(fltmp,"w+");
	 kmax=0;
	 for(i=1;i<=innodes;i++)
	 {
	   for(j=0;j<=resolution[i];j++)
	   {
	      for(k=1;k<=outnodes;k++)
		  fprintf(fl6,"%lf ",antit_wts[i][j][k]);
	   	  fprintf(fl6,"\n");
	   }
	   fprintf(fl6,"\n");
	 }
	 for(i=1;i<=innodes;i++)
	 {
	 for(l=0;l<=resolution[i];l++)
	 for(j=1;j<=innodes;j++)
	 for(k=1;k<=outnodes;k++)
	 {
	     fprintf(fl6,"%d %d ",mask_min[i][l][j][k],mask_max[i][l][j][k]);
	 }
	 fprintf(fl6,"\n");
	 }
         for(i=1;i<=innodes;i++)
         for(j=1;j<=resolution[i]+1;j++)
         fprintf(fl6,"%f\n", binloc[i][j]);                 /// Let us print the bins.
 	 fflush(fl6);
	 fclose(fl6);
	 fl6=NULL;
	 cout << "Best result at round " << rnn<< endl;
 } //rank == 0 under case 1 ends here.
 }  // ans <> 1
/***********************************End of Case 1*******************************/
         if(rank==0)
	     {	
             strcpy(fltmp,fln);
             strcat(fltmp,".dat"); // data is read only by master.
             fl1=fopen(fltmp,"r");
	     cout << "Creating the Anticipated Network outputs\n";
	     }
	     strcpy(fltmp,fln);
	     strcat(fltmp,".awf");
	     fl6=NULL;
             fl6=fopen(fltmp,"r");
	     strcpy(fltmp,fln);
	     strcat(fltmp,".apf");
	     fl2=NULL;
	     if((fl2=fopen(fltmp,"r"))!=NULL)
	        {
	   		for (i=1;i<=innodes;i++) fscanf(fl2,"%d",&resolution[i]);
			fscanf(fl2,"\n%f",&omax);
			fscanf(fl2,"%f",&omin);
			fscanf(fl2,"\n");
		        for(i=1;i<=innodes;i++) fscanf(fl2,"%f",&max[i]);
		        fscanf(fl2,"\n");
	        	for(i=1;i<=innodes;i++) fscanf(fl2,"%f",&min[i]);
		 	fscanf(fl2,"\n");
		 	for(i=1;i<=innodes;i++)
		 	{
			  for(j=0;j<=resolution[i];j++)
			  {
				 for(k=1;k<=outnodes;k++)
				 {
				 fscanf(fl2,"%d",&anti_net[i][j][k]);
				 fscanf(fl6,"%lf",&anti_wts[i][j][k]);
				 }
				 fscanf(fl2,"\n");
				 fscanf(fl6,"\n");
			  }
			  fscanf(fl6,"\n");
	                  fscanf(fl2,"\n");
	       }
           for(i=1;i<=innodes;i++)
           {
           for(l=0;l<=resolution[i];l++)
		   for(j=1;j<=innodes;j++)
		   for(k=1;k<=outnodes;k++)
		   {
		     fscanf(fl6,"%d",&mask_min[i][l][j][k]);
		     fscanf(fl6,"%d",&mask_max[i][l][j][k]);
		   }
		   fscanf(fl6,"\n");
		   }
		 }
     		  else
	 	  {
 	 	 	cout << "Unable to Open the APF information file";
			exit(1);
	 	  }
     	          for(i=1;i<=innodes;i++)
	          for(j=1;j<=resolution[i]+1;j++)
		  {
	          fscanf(fl6,"%lf\n",&binloc[i][j]);                 /// Let us print the bins.
		  }
		  fclose(fl6);
		if(rank==0)  // Output file is made only by master.
		{
     		  fl4=fopen("output.dat","w+");  // Network Output values
	// *********** case 3 ***********************************************
	          if (ans1 !=3)
		  {
		   fl5=fopen("actual.dat","w+");  // Expected Output Values
     		   strcpy(fltmp,fln);
     		   strcat(fltmp,argp[2]);
     		/*   strcat(fltmp,".factor");
		   fl9=fopen(fltmp,"w+");         // Lets see how well the classification went.
     		 */
		   strcpy(fltmp,fln);
     		   strcat(fltmp,argp[2]);
     		   strcat(fltmp,".cmp");         // Lets see how well the classification went.
     		   fl7=fopen(fltmp,"w+");
     		   fprintf(fl7, "Sample   Predicted   Predicted   Actual       Confidence level\n");
     		   fprintf(fl7," No.    Ist Choice  2nd Choice   item        in the prediction \n");
     		   c1cnt=0;
     		   c2cnt=0;
     		   invcnt=0;
     		   n=0;
		  }
		 } // rank ==0.
           // Create classtot values ***********************
	      for(i=1;i<=innodes;i++)for(j=0;j<=resolution[i];j++) classtot[i][j]=0;
	      for(i=1;i<=innodes;i++)
	      for(j=0;j<=resolution[i];j++)
	      for(k=1;k<=outnodes;k++) classtot[i][j]+= (anti_net[i][j][k]);
	    // *************************************************
         for(i=1;i<=innodes;i++) factor[i]=0.0;
	 if(rank==0)
	 {
	  sendcnt=0;
	  j=1; // We use j to keep track of who is getting the data.
          while (!feof(fl1))
	   {
//	   MPI_Send(&waiting,1,MPI_INT,j,waitlbl,MPI_COMM_WORLD);
	   for (i=1;i<=innodes;i++) 
	   {
	   fscanf(fl1,"%f",&vects[i]);
//           cout << "Send " << vects[i] << " for " << j << "\n";
	   }
	   fscanf(fl1,"%f\n",&tmpv);
	   vects[0]=(float) waiting;
	   vects[innodes+1]=tmpv;
	   MPI_Send(&vects[0],innodes+2,MPI_FLOAT,j,vectlbl,MPI_COMM_WORLD);
//	   cout << "Send " << tmpv << " for " << j << "\n" << "END OF ROUND \n";
           sendcnt++;
	   if ((j==(numtasks-1))||(feof(fl1)))
	   { 
	   k++;
/*	   if(k==numtasks)
	   {
	   k=0;
*/  
           j=getandsave(j);
//	   }
	    }
	   else 
	    j++;
	   }
	 }
	 if(rank >0)
	  {
	  while(waiting==1)
	  {
//	   cout << "I am waiting for data \n";
	   MPI_Recv(&vects[0],innodes+2,MPI_FLOAT,0,vectlbl,MPI_COMM_WORLD,&Stat);
	   waiting=(int)vects[0];
	   if(waiting==0)
	     continue;
	   tmpv=vects[innodes+1];
/*	   for(i=1;i<=innodes;i++)
	   cout << "Recieved [input] " << vects[i] << " for " << rank << "\n";
	   cout << "Recieved [class] " << tmpv << " for " << rank << "\n";
*/		     cmax= 0.0;
		     c2max=0.0;
		     kmax=0;
		     k2max=0;
 	 classval[0]=0.0;
	      for(i=1;i<=innodes;i++) vects[i]=(vects[i]-min[i])/(max[i]-min[i])*resolution[i];
		 for (i=1;i<=innodes;i++)
		 {
		     j=0;
	       k=1;
	       oldj=(double)2*resolution[i];
         while (fabs(vects[i]-binloc[i][j+1]) < oldj)
         {
            oldj=fabs(vects[i]-binloc[i][j+1]);
            j++;
          }
          j--;
        for (k=1;k<=outnodes;k++)
		    {
		     tmp2_wts=(double)anti_net[i][j][k]/classtot[i][j];
		     for(l=1;l<=innodes;l++)
		    {
        if(mask_max[i][j][l][k] < 0) tmp2_wts=tmp2_wts*fst_gain;
        else
	   		if(( vects[l] < ((double)resolution[l]*TabLookUp[mask_min[i][j][l][k]]-(double)resolution[l]*TabLookUp[mask_min[i][j][l][k]]*bgain/100.0)) || (vects[l] > ((double)resolution[l]*TabLookUp[mask_max[i][j][l][k]]+ (double)resolution[l]*TabLookUp[mask_max[i][j][l][k]]*bgain/100.0)))
        tmp2_wts=tmp2_wts*fst_gain;
        }
	      if(i==1) classval[k]=tmp2_wts*anti_wts[i][j][k];
		    else
		    classval[k]*=tmp2_wts*anti_wts[i][j][k];
		    } // for outnodes ends here
		
     } // for innodes ends here
  		    totprob=0.0;
		    for (k=1;k<=outnodes;k++)
		    {
		    if (classval[k] > cmax)
		    {
           c2max=classval[kmax];
			     k2max=kmax;
		       cmax=classval[k];
		       kmax=k;
        }
        else
        if (classval[k]>c2max)
        {
            c2max=classval[k];
			      k2max=k;
        }
		    totprob += (double)classval[k];
         }
	
	//	     cout << "The margin value is " << dmyclass[0];
	 for (i=1;i<=innodes;i++)
	 {
	     j=0;
	     oldj=(double)2*resolution[i];
         while (fabs(vects[i]-binloc[i][j+1]) < oldj)
         {
            oldj=fabs(vects[i]-binloc[i][j+1]);
            j++;
          }
          j--;
	 tmp2_wts=(double)anti_net[i][j][(int)tmpv]/classtot[i][j];
	 for(l=1;l<=innodes;l++)
	    {
        if(mask_max[i][j][l][(int)tmpv] < 0) tmp2_wts=tmp2_wts*fst_gain;
        else
	 if(( vects[l] < ((double)resolution[l]*TabLookUp[mask_min[i][j][l][(int)tmpv]]-(double)resolution[l]*TabLookUp[mask_min[i][j][l][(int)tmpv]]*bgain/100.0)) || (vects[l] > ((double)resolution[l]*TabLookUp[mask_max[i][j][l][(int)tmpv]]+ (double)resolution[l]*TabLookUp[mask_max[i][j][l][(int)tmpv]]*bgain/100.0)))
        tmp2_wts=tmp2_wts*fst_gain;
        }
	factor[i]+=tmp2_wts;
	
	}
// Factors computed
//            cout << "Ready to send values. I am " << rank << "\n";
//            if(rank==0)
//	    j=getandsave(sendcnt-n);

            mycombuf[1] = (double) kmax;
	    mycombuf[2] = (double) k2max;
	    mycombuf[3] = (double) tmpv;
	    mycombuf[4] = totprob;
	    mycombuf[5] = classval[kmax];
	    MPI_Send(&mycombuf[1],5,MPI_DOUBLE,0,kmaxlbl,MPI_COMM_WORLD);
	} // Original while not eof ends here.
	} 
	waiting=0;
	vects[0]=(float) waiting;
	if(rank==0)
	{
	for(i=1;i<numtasks;i++)
          MPI_Send(&vects[0],innodes+2,MPI_FLOAT,i,vectlbl,MPI_COMM_WORLD);
	}
	MPI_Finalize();
	 
//		cout << "The slave node " << rank << " is exiting\n"; 
		 if (rank==0)
		 {
	         fclose(fl2);
	         fclose(fl1);
		 fclose(fl4);
		 if(ans1 !=3)
		 {
        	 fclose(fl5);
		 fprintf(fl7,"*________________________________________________________________________\n");
		 fprintf(fl7,"*Total    Success in   Success in   Non classified   Real success in    \n");
		 cout << "*________________________________________________________________________\n";
		 cout << "*Total    Success in   Success in   Non classified   Real success in    \n";
		if (outnodes > 2)
		 {
     		 fprintf(fl7,"* No.    Ist Choice  2nd Choice     items           two chances    \n");
     		 fprintf(fl7,"* %d       %d          %d           %d             %-7.4f %% \n",n,c1cnt,c2cnt,invcnt,(float)100.0*(c1cnt+c2cnt)/(n-invcnt));
     		 cout << "* No.    Ist Choice  2nd Choice     items           two chances    \n";
     		 printf("* %d       %d          %d           %d             %-7.4f %% \n",n,c1cnt,c2cnt,invcnt,(float)100.0*(c1cnt+c2cnt)/(n-invcnt));
     		}
     		 else
     		 {
     		 fprintf(fl7,"* No.    Ist Choice  2nd Choice     items           First chance    \n");
     		 fprintf(fl7,"* %d       %d          %d           %d             %-7.4f %% \n",n,c1cnt,c2cnt,invcnt,(float)100.0*(c1cnt)/(n-invcnt));
     		 cout << "* No.    Ist Choice  2nd Choice     items           First chance    \n";
     		 printf("* %d       %d          %d           %d             %-7.4f %% \n",n,c1cnt,c2cnt,invcnt,(float)100.0*(c1cnt)/(n-invcnt));
     		}
	  	 fprintf(fl7,"*________________________________________________________________________\n");
		 printf("*________________________________________________________________________\n");
		 fclose(fl7);
		 } // ******** ans1!=3 ends here *************
		 }
                 delete[] TabLookUp;
                 delete[] anti_net;          // Let us free all memory!!
		 delete[] anti_wts;
		 delete[] antit_wts;
		 delete[] antip_wts;
		 delete[] classtot;
		 delete[] mask_min;
		 delete[] mask_max;
		 delete[] binrec;
	         delete[] tbinrec;  // we no longer need it.
		 delete[] binloc;
//*/
                 if(rank==0)
		 {
		 cout << "Done.\n";
		 stop = times(NULL);
		 cout << "The computation took " << fabs(start - stop)*10000/(CLOCKS_PER_SEC) << " Secs.\n";
		 }
return 0;
 } //end main


