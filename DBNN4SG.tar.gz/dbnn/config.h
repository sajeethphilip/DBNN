/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Name of package */
#define PACKAGE "dbnn"

/* Version number of package */
#define VERSION "2.1"

/* C++ compiler supports template repository */
#define HAVE_TEMPLATE_REPOSITORY 1

