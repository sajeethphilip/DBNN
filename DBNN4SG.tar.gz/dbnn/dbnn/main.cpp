/***************************************************************************
                          main.cpp  -  description
                             -------------------
    begin                : Sat Oct 13 11:58:21 IST 2001
    copyright            : (C) 2001 by Ninan Sajeeth Philip
    email                : nsp@stthom.ernet.in
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/*
Nov. 2001 : Version 2.2
Sept.20th 2001
This is version 2.1 of the DBNN software. The major change here is that a network topology is
considered better over the other by computing the total probability of success when there in no
increase in the number of success counts. rslt orslt prslt changed to floats from integer mode.
A new variable pcnt and pocnt now holds the success counts. The second change is in initializing
the arrays - new c++ in RedHat 7.x require this to avoid segmentation error!

Program to generate anticipation inputs for the training/test set(c)Sajith Philip 1999.
This program is Public Domain. You have all rights to modify and use it. But please acknowledge
the original author and the cite that contains the details of this network.
You may download a technical paper on this network from:
                    www.geocities.com/sajithphilip/research.htm
To run the program, you need an information file and a training and test data set. The format
of these files are explained later in this file.

Enjoy!

Sajith Philip
*/
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <iostream.h>
#include <stdlib.h>
#include<sys/times.h> // times() fun. is here.
#include <time.h>
// Increase the resolution to improve finer details, provided there is a huge training set.
#define max_resol 500
#define features 500
#define classes 500           // If you get segmentation errors, reduce these values to fit your
//#define oneround 100       //  Memory size.
#define fst_gain 0.25
static double gain,dmyclass[classes],classval[classes],cmax,c2max,tmp2_wts,totprob,oldj;
static float vects[features+classes+1],tmpv,max[features],min[features],omax,omin,rslt,rslt2,orslt,orslt2,prslt,nrslt;
clock_t start,stop;
static int oneround=100,flg1,kmax,k2max,ans1,rnn,rnd,i,j,k,l,n,c1cnt,c2cnt,pcnt,pocnt,invcnt,innodes,outnodes,resolution[features+1];
char fln[256],fltmp[256];
FILE *fl1,*fl2,*fl3,*fl4,*fl5,*fl6,*fl7,*fl8;
int main(int argv, char *argp[256])
{
     cout << "Create the APF file(0) or Create the Weights file (1) or Classify Data(2) ?";
     cin >> ans1;
//	 scanf("%d",&ans1);
	 if(*strcpy(fltmp,argp[1])=='\0')
     {
     cout << "Enter the name of the input file without extension :";
     cin >> fln;
     //scanf ("%s",&fln);
     }
     else
     {
     strcpy(fln,argp[1]);
     }
     strcpy(fltmp,fln);
     strcat(fltmp,".dat");
/*
  The structure of the data file is:
  Feature1 Feature2 Feature3 ....(etc upto innodes) ActualClass
  Feature1 Feature2 Feature3 ....(etc upto innodes) ActualClass
  Feature1 Feature2 Feature3 ....(etc upto innodes) ActualClass
  The delimiters are spaces and not tabs!!
*/
     if((fl1=fopen(fltmp,"r"))!=NULL)
     {
	    strcpy(fltmp,fln);
	    strcat(fltmp,".inf");
/*
  The format of the info file is: (in each line enter)
  innodes
  outnodes
  margin   <- This addition is required for regression problems.
  1.0       <- You can give any real positive value here. It is just a label.
  2.0
  ... (etc. upto no of classes)
*/	
     	if((fl2=fopen(fltmp,"r"))!=NULL)
	    {
		 i=0;
		 fscanf(fl2,"%d",&innodes);
		 fscanf(fl2,"%d",&outnodes);
		 for (i=0;i<=outnodes;i++) // dmyclass[0] contains margin others are expected values.
		 fscanf(fl2,"%lf",&dmyclass[i]);
			
	    }
	    else
	    {
		 cout << "Unable to find the Info file. Exiting !!";
		 exit(1);
	    }
  
     } // program ends.
     else   // data file read error.
     {
      cout << "Unable to open the data file";
      exit(1);
      }
      gain=2.0;
 /**************** Let us Define the Network Structure *********************************/
 double (* anti_net)[max_resol+1][outnodes+1];
 anti_net  = new double[innodes+1][max_resol+1][outnodes+1]; // Our Network
 double (* anti_wts)[max_resol+1][outnodes+1];
 anti_wts  = new double[innodes+1][max_resol+1][outnodes+1]; // Connection wts.
 double (* antit_wts)[max_resol+1][outnodes+1];
 antit_wts = new double[innodes+1][max_resol+1][outnodes+1]; // Temp. storage
 double (* antip_wts)[max_resol+1][outnodes+1];
 antip_wts = new double[innodes+1][max_resol+1][outnodes+1]; // Temp. last best.
 double (* classtot)[max_resol+1];
 classtot  = new double[innodes+1][max_resol+1];           // Total Prob. computed
 double (* mask_min)[max_resol+1][innodes+1][outnodes+1];
 mask_min  = new double[innodes+1][max_resol+1][innodes+1][outnodes+1]; // Min Threshold
 double (* mask_max)[max_resol+1][innodes+1][outnodes+1];
 mask_max  = new double[innodes+1][max_resol+1][innodes+1][outnodes+1]; // Max Threshold
/***************************Let us put up the Network***********************************/
	      for(i=0;i<=innodes;i++)
	      for(j=0;j<=resolution[i];j++)
	      for(k=0;k<=outnodes;k++)
	      {
	      anti_net[i][j][k]=(double)(1.0/(resolution[i]*innodes*outnodes)); // Restored Nov. 16th 2001
	      anti_wts[i][j][k]=(double)(1.0);
	      }
              for(i=0;i<=innodes;i++)
	       for(j=0;j<=resolution[i];j++)
	       for(l=0;l<=innodes;l++)
	     for(k=0;k<=classes;k++)
	      {
	      mask_min[i][j][l][k]=-1.0;
	      mask_max[i][j][l][k]=-1.0;
	      }
//    Start the counter for case 2 here.................
             start = times(NULL);
             if (ans1==0)
	    {
	      n=0;
	      omax=-40;
	      omin=40;
	      while (!feof(fl1))
	      {
		 for(i=1;i<=innodes;i++)
		 if (n==0)
		 {
		   fscanf(fl1,"%f",&max[i]);
		   min[i]=max[i];
		 }
		 else
		 {
		   fscanf(fl1,"%f",&tmpv);
		   if( tmpv> max[i]) max[i]=tmpv;
		   if (min[i] > tmpv) min[i]=tmpv;
		 }
		 fscanf(fl1,"%f\n",&tmpv);
		 if(tmpv>omax) omax = tmpv;
                 if(tmpv<omin) omin =tmpv;
		 n++;
	      }
	      cout << "No of vectors =" << n <<" and i/n is= " << 1.0/n << "\n";
  /*
      For each feature we assign 'n' number of bins to catch the details. This is what we mean
      by resolution. Start with low values for better generalization features of the network.
      Larger value will however help you to resolve the finer details. The moral is that the
      exact value has to be computed by trial and error.
  */
              for(i=1;i<=innodes;i++)
	      {
                cout << "Enter the resolution required for node " << i << "[" << max_resol << "] (1 to " << max[i]-min[i] << "): ";
                cin >> resolution[i];
//	        scanf("%d",&resolution[i]);
	      }
	      for(i=0;i<=innodes;i++)
	      for(j=0;j<=resolution[i];j++)
	      for(k=0;k<=outnodes;k++)
	      {
	      anti_net[i][j][k]=(double)(1.0/(resolution[i]*innodes*outnodes));  // Restored Nov.16 2001
	      anti_wts[i][j][k]=(double)(1.0);
	      }
	      // Start the counter now...............
	      start = times(NULL);
              for(i=0;i<=innodes;i++)
	       for(j=0;j<=resolution[i];j++)
	       for(l=0;l<=innodes;l++)
	     for(k=0;k<=classes;k++)
	      {
	      mask_min[i][j][l][k]=-1.0;
	      mask_max[i][j][l][k]=-1.0;
	      }
	     rewind(fl1);
	      while (!feof(fl1))
	      {
	        for (i=1;i<=innodes;i++) fscanf(fl1,"%f",&vects[i]);
	 	fscanf(fl1,"%f\n",&tmpv);
	 	for(i=1;i<=innodes;i++)
	 	vects[i]=(float)(vects[i]-min[i])/(max[i]-min[i])*resolution[i];
	 	for (i=1;i<=innodes;i++)
	 	{
		  j=0;
	     	  k=1;
	     	  l=0;
	     	  oldj=(double)2*resolution[i];
	     	  while (sqrt(pow((vects[i]-j),2)) < oldj)
	     	  {
	     	  oldj=sqrt(pow((vects[i]-j),2));
	     	  j++;
	     	  }
	     	  j--;
		  k=1;
		  while ((fabs(tmpv - dmyclass[k])) > dmyclass[0]) k++;
		   (anti_net[i][j][k])++;
        	  for (l=1;l<=innodes;l++)
              {
        	  if(mask_min[i][j][l][k] ==-1.0)
        	  {mask_min[i][j][l][k]=vects[l];
        	  }
        	  else
        	  if(mask_min[i][j][l][k] > vects[l])
        	  {mask_min[i][j][l][k]=vects[l];
        	  }
        	  if(mask_max[i][j][l][k] ==-1.0)
        	  {mask_max[i][j][l][k]=vects[l];
        	  }
        	  else
        	  if(mask_max[i][j][l][k] < vects[l])
        	  {mask_max[i][j][l][k]=vects[l];
        	  }
        	  }
   	 	  }
	      }
	      fclose(fl1);
	      fclose(fl2);
              for(i=1;i<=innodes;i++)for(j=0;j<=resolution[i];j++) classtot[i][j]=0.0;
	      for(i=1;i<=innodes;i++)
	      for(j=0;j<=resolution[i];j++)
	      for(k=1;k<=outnodes;k++) classtot[i][j]+= (anti_net[i][j][k]);
	      for(i=1;i<=innodes;i++)
	      for(j=0;j<=resolution[i];j++)
	      for(k=1;k<=outnodes;k++)
              if(classtot[i][j]>0)
              {
                 (anti_net[i][j][k])=((anti_net[i][j][k])/ classtot[i][j]);
               }
         /*
            The conditional Probability,
	    P(A|B) = P(A intersection B)/P(B) is the
	    probability for the occurance of A(k) if B(ij) has happened =
	    Share of B(ij) that is held by A(k) / Probability of total B(ij)
	    in that particular feature i with resolution j.

                      */
              strcpy(fltmp,fln);
	      strcat(fltmp,".awf");      // This file holds the weights
	      fl6=fopen(fltmp,"w+");
	      strcpy(fltmp,fln);
	      strcat(fltmp,".apf");     // This file holds the estimated probability
	      if((fl1=fopen(fltmp,"w+"))!=NULL)
	      {
		 for(i=1;i<=innodes;i++) fprintf(fl1,"%d ",resolution[i]);
		 fprintf(fl1,"\n%f %f \n",omax,omin);
		 for(i=1;i<=innodes;i++) fprintf(fl1,"%f ",max[i]);
		 fprintf(fl1,"\n");
		 for(i=1;i<=innodes;i++) fprintf(fl1,"%f ",min[i]);
		 fprintf(fl1,"\n");
		 for(i=1;i<=innodes;i++)
		 {
		   for(j=0;j<=resolution[i];j++)
		   {
			 for(k=1;k<=outnodes;k++)
			 {
			 fprintf(fl1,"%f ",anti_net[i][j][k]);
			 fprintf(fl6,"%f ",anti_wts[i][j][k]);
			 }
			 fprintf(fl6,"\n");
			 fprintf(fl1,"\n");
		   }
		   fprintf(fl6,"\n");
	       fprintf(fl1,"\n");
		 }
		  for(i=1;i<=innodes;i++)
		  {
		  for(l=0;l<=resolution[i];l++)
		  for(j=1;j<=innodes;j++)
		  for(k=1;k<=outnodes;k++)
		  {
		    fprintf(fl6,"%f %f ",mask_min[i][l][j][k],mask_max[i][l][j][k]);
		  }
		  fprintf(fl6,"\n");
		  }
	   }
	      else
	      {
		 cout << "Unable to create file for output\n";
		 exit(1);
	      }
	      fclose(fl1);
	      fclose(fl6);
	      fflush(NULL);
	      cout << "Creating the Anticipated Weights data file\n";
	   }
/**********************************End of Case 0 ******************************/
if(ans1==1)
{
    start = times(NULL);
    pcnt=0;
    pocnt=0;
    rslt=0.0;
    rslt2=0.0;
    orslt=rslt;
    orslt2=rslt2;
    cout << "The programe will now modify the compensatory weights\n";
    cout << "Please enter the gain:";
    cin >> gain;
    cout << "Please enter the number of training epochs:";
    cin >> oneround;
    // Start the counter in this round here...................
    start = times(NULL);
    strcpy(fltmp,fln);
	strcat(fltmp,".awf");
	fl6=fopen(fltmp,"r");
	strcpy(fltmp,fln);
	strcat(fltmp,".apf");
	fl2=NULL;
	if((fl2=fopen(fltmp,"r"))!=NULL)
    {
			for (i=1;i<=innodes;i++) fscanf(fl2,"%d",&resolution[i]);
			fscanf(fl2,"\n%f",&omax);
			fscanf(fl2,"%f",&omin);
			fscanf(fl2,"\n");
		    for(i=1;i<=innodes;i++) fscanf(fl2,"%f",&max[i]);
		    fscanf(fl2,"\n");
	      	for(i=1;i<=innodes;i++) fscanf(fl2,"%f",&min[i]);
		 	fscanf(fl2,"\n");
		 	for(i=1;i<=innodes;i++)
		 	{
			  for(j=0;j<=resolution[i];j++)
			  {
				 for(k=1;k<=outnodes;k++)
				 {
				 fscanf(fl2,"%lf",&anti_net[i][j][k]);
				 fscanf(fl6,"%lf",&anti_wts[i][j][k]);
				 antit_wts[i][j][k]=anti_wts[i][j][k];
				 antip_wts[i][j][k]=anti_wts[i][j][k];
				 }
				 fscanf(fl2,"\n");
				 fscanf(fl6,"\n");
			  }
			  fscanf(fl2,"\n");
	                  fscanf(fl6,"\n");
	       }
	  	   for(i=1;i<=innodes;i++)
	  	   {
	  	   for(l=0;l<=resolution[i];l++)
	  	   for (j=1;j<=innodes;j++)
		   for(k=1;k<=outnodes;k++)
		   {
		     fscanf(fl6,"%lf",&mask_min[i][l][j][k]);
		     fscanf(fl6,"%lf",&mask_max[i][l][j][k]);
		   }
		   fscanf(fl6,"\n");
		   }
	   }
       else
	   {
 	 	cout << "Unable to Open the APF information file\n";
		exit(1);
	}
    fclose(fl2);
	fclose(fl6);
	for(rnd=0;rnd<=oneround;rnd++)     // Training round starts here....
    {
       strcpy(fltmp,fln);
       strcat(fltmp,".dat");
       fl1=fopen(fltmp,"r");
  	   n=0;
       rslt=0.0;
       rslt2=0.0;
       pcnt=0;
       while (!feof(fl1))
	   {
	      n++;
	      for (i=1;i<=innodes;i++) fscanf(fl1,"%f",&vects[i]);
	      fscanf(fl1,"%f\n",&tmpv);
	      for(i=1;i<=innodes;i++)
	      vects[i]=(vects[i]-min[i])/(max[i]-min[i])*resolution[i];
		  for (i=1;i<=innodes;i++)
		  {
		      j=0;
	          k=1;
	          oldj=(double)2*resolution[i];
	          while ((sqrt(pow((vects[i]-j),2)) < oldj)&& (j<=resolution[i]))
		      {
		        oldj=sqrt(pow((vects[i]-j),2));
		        j++;
		      }
		      j--;
              for (k=1;k<=outnodes;k++)
		      {
		         tmp2_wts=0.0;
		         tmp2_wts=anti_net[i][j][k]*fst_gain;
		         flg1=0;
		         for(l=1;l<=innodes;l++)
		         if((mask_min[i][j][l][k] > vects[l])||(vects[l] > mask_max[i][j][l][k]))
		         {
		           flg1=1;
		        }
		        if (flg1==0) tmp2_wts=anti_net[i][j][k];
		        if(i==1) classval[k]=tmp2_wts*anti_wts[i][j][k];
	            else
		        classval[k]*=tmp2_wts*anti_wts[i][j][k];
		      }

		   }
		   kmax=0;
		   cmax=0;
		   for (k=1;k<=outnodes;k++)
		   {
		      if (classval[k] > cmax)
		      {
			   cmax=classval[k];
			   kmax=k;
		      }
		   }
		   if ((fabs(dmyclass[kmax]-tmpv) > dmyclass[0]) && (rnd >0))
	       {
	          for (i=1;i<=innodes;i++)
	          {
		        j=0;
	            k=1;
	            oldj=(double)2*resolution[i];
	            while ((sqrt(pow((vects[i]-j),2)) < oldj)&& (j<=resolution[i]))
		        {
		           oldj=sqrt(pow((vects[i]-j),2));
		           j++;
		        }
		        j--;
			k=1;
                while (fabs(dmyclass[k]-tmpv) > dmyclass[0]) k++;
		        {
		        anti_wts[i][j][k]+=gain*(float)(1.0-(classval[k]/classval[(int)kmax]));
                }
			
	           }
	         } // kmax check
		 } // while not eof check
		 // Now save the wieights
		 fclose(fl1);
	  strcpy(fltmp,fln);
       strcat(fltmp,".dat");
       fl1=fopen(fltmp,"r");
  	   n=0;
       rslt=0.0;
       rslt2=0.0;
       pcnt=0;
       while (!feof(fl1))                    // Test round...
	   {
	      n++;
	      for (i=1;i<=innodes;i++) fscanf(fl1,"%f",&vects[i]);
	      fscanf(fl1,"%f\n",&tmpv);
	      for(i=1;i<=innodes;i++)
              {
	      vects[i]=(vects[i]-min[i])/(max[i]-min[i])*resolution[i];
              if (vects[i] < 0) vects[i]=0;             // let us be bounded. #Oct 2001.
              if(vects[i] > resolution[i]) vects[i]=resolution[i];
              }
		  for (i=1;i<=innodes;i++)
		  {
		      j=0;
	          k=1;
	          oldj=(double)2*resolution[i];
	          while ((sqrt(pow((vects[i]-j),2)) <= oldj)&& (j<=resolution[i]))
		      {
		        oldj=sqrt(pow((vects[i]-j),2));
		        j++;
		      }
		      j--;
              for (k=1;k<=outnodes;k++)
		      {
		         tmp2_wts=0.0;
		         tmp2_wts=anti_net[i][j][k]*fst_gain;
		         flg1=0;
		         for(l=1;l<=innodes;l++)
		         if((mask_min[i][j][l][k] > vects[l])||(vects[l] > mask_max[i][j][l][k]))
		         {
		           flg1=1;
		        }
		        if (flg1==0) tmp2_wts=anti_net[i][j][k];
		        if(i==1) classval[k]=tmp2_wts*anti_wts[i][j][k];
	            else
		        classval[k]*=tmp2_wts*anti_wts[i][j][k];
		      }
			
		   }
		   kmax=0;
		   cmax=0;
		   for (k=1;k<=outnodes;k++)
		   {
		      if (classval[k] > cmax)
		      {
			   cmax=classval[k];
			   kmax=k;
		      }
		   }
		   if (fabs(dmyclass[kmax]-tmpv) <= dmyclass[0])
		   {
	            rslt2+=cmax;
		     pcnt++;
		   }
	           else
		   {
		   k=1;
	           while (fabs(dmyclass[k]-tmpv) > dmyclass[0]) k++;
	           rslt+=cmax-classval[k];
		    }
		 } // while not eof check
		 // Now save the wieights
		 fclose(fl1);
	     kmax=0;
	    // if((orslt2 < rslt2)&&(orslt< rslt)||(pcnt>pocnt))
              if(orslt2==0) orslt2=rslt2;
              if(orslt==0) orslt=rslt;
	      prslt=(rslt2-orslt2);
	      nrslt=(orslt/rslt);
             // prslt>0.0 ||
	      if((prslt>0.0 && nrslt>1.0)||(pcnt>pocnt))
	     {
	       rnn=rnd;
	       pocnt=pcnt;   // The best result is now saved in pocnt
	       for(i=1;i<=innodes;i++)
	       {
	           for(j=0;j<=resolution[i];j++)
		    {
		      for(k=1;k<=outnodes;k++)
		      {
		      antip_wts[i][j][k]=antit_wts[i][j][k];
		      antit_wts[i][j][k]=anti_wts[i][j][k];
	              }
		    }
	       }
	       cout << "Round:" << rnn << "| TProb["<<prslt<<"," <<nrslt<<"] | Passed count:" << pocnt << endl;
	       if(orslt2 <rslt2) orslt2=rslt2;
	       if(rslt < orslt) orslt=rslt;
	     }
	    // prslt=rslt+rslt2;
	 }  //rnd inc.
	 strcpy(fltmp,fln);
	 strcat(fltmp,".awf");
	 fl6=fopen(fltmp,"w+");
	 kmax=0;
	 for(i=1;i<=innodes;i++)
	 {
	   for(j=0;j<=resolution[i];j++)
	   {
	      for(k=1;k<=outnodes;k++)
		  fprintf(fl6,"%f ",antit_wts[i][j][k]);
	   	  fprintf(fl6,"\n");
	   }
	   fprintf(fl6,"\n");
	 }
	 for(i=1;i<=innodes;i++)
	 {
	 for(l=0;l<=resolution[i];l++)
	 for(j=1;j<=innodes;j++)
	 for(k=1;k<=outnodes;k++)
	 {
	     fprintf(fl6,"%f %f ",mask_min[i][l][j][k],mask_max[i][l][j][k]);
	 }
	 fprintf(fl6,"\n");
	 }
	 fflush(fl6);
	 fclose(fl6);
	 fl6=NULL;
	 cout << "Best result at round " << rnn<< endl;
 }  // ans <> 1
/***********************************End of Case 1*******************************/	
             strcpy(fltmp,fln);
             strcat(fltmp,".dat");
             fl1=fopen(fltmp,"r");
	     strcpy(fltmp,fln);
	     strcat(fltmp,".awf");
	     fl6=NULL;
             fl6=fopen(fltmp,"r");
	     strcpy(fltmp,fln);
	     strcat(fltmp,".apf");
	     fl2=NULL;
	     if((fl2=fopen(fltmp,"r"))!=NULL)
	        {
	                cout << "Creating the Anticipated Network outputs\n";
	   		for (i=1;i<=innodes;i++) fscanf(fl2,"%d",&resolution[i]);
			fscanf(fl2,"\n%f",&omax);
			fscanf(fl2,"%f",&omin);
			fscanf(fl2,"\n");
		        for(i=1;i<=innodes;i++) fscanf(fl2,"%f",&max[i]);
		        fscanf(fl2,"\n");
	        	for(i=1;i<=innodes;i++) fscanf(fl2,"%f",&min[i]);
		 	fscanf(fl2,"\n");
		 	for(i=1;i<=innodes;i++)
		 	{
			  for(j=0;j<=resolution[i];j++)
			  {
				 for(k=1;k<=outnodes;k++)
				 {
				 fscanf(fl2,"%lf",&anti_net[i][j][k]);
				 fscanf(fl6,"%lf",&anti_wts[i][j][k]);
				 }
				 fscanf(fl2,"\n");
				 fscanf(fl6,"\n");
			  }
			  fscanf(fl6,"\n");
	                  fscanf(fl2,"\n");
	       }
           for(i=1;i<=innodes;i++)
           {
           for(l=0;l<=resolution[i];l++)
		   for(j=1;j<=innodes;j++)
		   for(k=1;k<=outnodes;k++)
		   {
		     fscanf(fl6,"%lf",&mask_min[i][l][j][k]);
		     fscanf(fl6,"%lf",&mask_max[i][l][j][k]);
		   }
		   fscanf(fl6,"\n");
		   }
		 }
     		  else
	 	  {
 	 	 	cout << "Unable to Open the APF information file";
			exit(1);
	 	  }
     		  fclose(fl6);
              //fl3=fopen("Learning.dat","w+");    // Just for cross validation
     		  fl4=fopen("output.dat","w+");  // Network Output values
     		  fl5=fopen("actual.dat","w+");  // Expected Output Values
     	//	  strcpy(fltmp,argp[2]);
     	//	  strcat(fltmp,".dat");
     	//	  fl8=fopen(fltmp,"w+");
     		  strcpy(fltmp,fln);
     		  strcat(fltmp,argp[2]);
     		  strcat(fltmp,".cmp");         // Lets see how well the classification went.
     		  fl7=fopen(fltmp,"w+");
     		  fprintf(fl7, "Sample   Predicted   Predicted   Actual       Confidence level\n");
     		  fprintf(fl7," No.    Ist Choice  2nd Choice   item        in the prediction \n");
     		  c1cnt=0;
     		  c2cnt=0;
     		  invcnt=0;
     		  n=0;
     		  while (!feof(fl1))
		  {
		         n++;
	            for (i=1;i<=innodes;i++) fscanf(fl1,"%f",&vects[i]);
	            fscanf(fl1,"%f\n",&tmpv);
	            for(i=1;i<=innodes;i++) vects[i]=(vects[i]-min[i])/(max[i]-min[i])*resolution[i];
		    for (i=1;i<=innodes;i++)
		    {
		      j=0;
	              k=1;
	              oldj=(double)2*resolution[i];
	          while ((sqrt(pow((vects[i]-j),2)) < oldj)&& (j<=resolution[i]))
		      {
		      oldj=sqrt(pow((vects[i]-j),2));
		      j++;
		      }
		      j--;  // We inc. but error here is not less. so go back one step.
              for (k=1;k<=outnodes;k++)
		      {
		        tmp2_wts=anti_net[i][j][k]*fst_gain;
		        flg1=0;
		        for(l=1;l<=innodes;l++)
		        if((mask_min[i][j][l][k] > vects[l])||(vects[l] > mask_max[i][j][l][k]))
		        {
		         flg1=1;
		        }
		        if (flg1==0) tmp2_wts=anti_net[i][j][k];
//                        fprintf(fl8,"%-6.4f ",tmp2_wts);
	            if(i==1) classval[k]=tmp2_wts*anti_wts[i][j][k];     
		        else
		        classval[k]*=tmp2_wts*anti_wts[i][j][k];             
		
		      }
			
		     }
//		     fprintf(fl8,"%-6.4f\n",(tmpv-1.0)/(outnodes-1));
		    cmax= 0.0;
		    c2max=0.0;
		    totprob=0.0;
		    kmax=0;
		    k2max=0;
//		    fprintf(fl3,"%d ",n);
		    for (k=1;k<=outnodes;k++)
		    {
		      totprob += (double)classval[k];
//		      fprintf(fl3,"%f ",classval[k]);
		      if (classval[k] > cmax)
		      {
		      if(kmax > 0)
		          {
			   c2max=classval[kmax];
			   k2max=kmax;
		           }
		
		      cmax=classval[k];
		      kmax=k;
		      }
		      else
		      if(classval[k] >= c2max)
		         {
		          c2max= classval[k];
		          k2max=k;
		         }
		     }
	//	     cout << "The margin value is " << dmyclass[0];
//		     fprintf(fl3,"%lf %lf \n", tmpv,dmyclass[(int)kmax]);
		     fprintf(fl4,"%d  %f \n",n, dmyclass[(int)kmax]);
		     fprintf(fl7, "%-8d    %lf   %lf     %lf    ",n,dmyclass[(int)kmax],dmyclass[(int)k2max],tmpv);
		     if(fabs(dmyclass[kmax]-tmpv) > dmyclass[0])
		     {
		     if (classval[kmax]==0.0)
		     {
		      invcnt++;
		      fprintf(fl7, "%-7.4f %% <-Out of range\n",100.0*((classval[kmax])/totprob));
		     }
		     else
		     {
		     if (fabs(dmyclass[k2max]-tmpv) <=dmyclass[0])
		      {
// The Next line defines the margin level required to pick up less confident examples!
		      if ((classval[kmax]-classval[k2max]) > (0.2*totprob/outnodes))
		       {
		       c2cnt++;  // No more differences. NSP (OCT 2001)
		       fprintf(fl7, "%-7.4f %% <-F(1)P(2)\n",100.0*((classval[kmax])/totprob));
		       }
		       else
		       {
		       invcnt++;
		       fprintf(fl7, "%-7.4f %% <-FMC\n",100.0*((classval[kmax])/totprob));
		       }
		      }
		      else
		      {
		      fprintf(fl7, "%-7.4f %% <-Failed\n",100.0*((classval[kmax])/totprob));
		      }
	            }
		    }
		    else
		     {
		     if (classval[kmax] > 1.2*totprob/outnodes)
		     {
		     fprintf(fl7, "%-7.4f %% \n",100.0*((classval[kmax])/totprob));
		     c1cnt++;
		     }
		      else
		        {
		        invcnt++;
		        fprintf(fl7, "%-7.4f %% <-PMC\n",100.0*((classval[kmax])/totprob));
		        }

		     }
		     fprintf(fl5,"%d %e \n",n,(float) tmpv);
		
	         }
	         fclose(fl1);
	         fclose(fl2);
//	    	 fclose(fl3);
		 fclose(fl4);
		 fclose(fl5);
		 fprintf(fl7,"*________________________________________________________________________\n");
		 fprintf(fl7,"*Total    Success in   Success in   Non classified   Real success in    \n");
		 cout << "*________________________________________________________________________\n";
		 cout << "*Total    Success in   Success in   Non classified   Real success in    \n";
		if (outnodes > 2)
		 {
     		 fprintf(fl7,"* No.    Ist Choice  2nd Choice     items           two chances    \n");
     		 fprintf(fl7,"* %d       %d          %d           %d             %-7.4f %% \n",n,c1cnt,c2cnt,invcnt,(float)100.0*(c1cnt+c2cnt)/(n-invcnt));
     		 cout << "* No.    Ist Choice  2nd Choice     items           two chances    \n";
     		 printf("* %d       %d          %d           %d             %-7.4f %% \n",n,c1cnt,c2cnt,invcnt,(float)100.0*(c1cnt+c2cnt)/(n-invcnt));
     		}
     		 else
     		 {
     		 fprintf(fl7,"* No.    Ist Choice  2nd Choice     items           First chance    \n");
     		 fprintf(fl7,"* %d       %d          %d           %d             %-7.4f %% \n",n,c1cnt,c2cnt,invcnt,(float)100.0*(c1cnt)/(n-invcnt));
     		 cout << "* No.    Ist Choice  2nd Choice     items           First chance    \n";
     		 printf("* %d       %d          %d           %d             %-7.4f %% \n",n,c1cnt,c2cnt,invcnt,(float)100.0*(c1cnt)/(n-invcnt));
     		}
	  	 fprintf(fl7,"*________________________________________________________________________\n");
		 printf("*________________________________________________________________________\n");
		 fclose(fl7);
//		 fclose(fl8);
		 delete[] anti_net;          // Let us free all memory!!
		 delete[] anti_wts;
		 delete[] antit_wts;
		 delete[] antip_wts;
		 delete[] classtot;
		 delete[] mask_min;
		 delete[] mask_max;
		 cout << "Done.\n";
		 stop = times(NULL);
		 cout << "The computation took " << fabs(start - stop)*10000/(CLOCKS_PER_SEC) << " Secs.\n";
	       // ans <> 2
	        // not 2,1,0



 } //end main
